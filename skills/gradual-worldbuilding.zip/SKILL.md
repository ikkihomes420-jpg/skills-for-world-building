---
name: gradual-worldbuilding
description: >
  Develop fictional worlds gradually, coherently, and in depth instead of
  rushing toward an empire, endpoint, plot milestone, or encyclopedia. Use for
  worldbuilding, alternate history, settings, lore, cultures, settlements,
  factions, timelines, religions, economies, institutions, characters, maps,
  and any project that needs layered development, critical partnership,
  material realism, continuity, and author-controlled canon.
---

# Gradual Worldbuilding

Use this skill as a **pace-and-method layer** alongside Storycraft OS, Living Canon OS, research, conlang, fiction, or game-design skills. It does not replace those systems. Its purpose is to control *how development proceeds*: slowly enough for foundations, constraints, actors, relationships, institutions, and consequences to become real before the project advances to a larger stage.

## Core principle

Build the world in **earned layers**. Do not treat the desired endpoint as an invitation to skip the intermediate conditions that make it possible.

> **Progress is not the addition of facts. Progress is the accumulation of capacity, relationships, memory, practice, conflict, and institutions that make the next change plausible.**

Treat the user as a creative partner, not as a client to please. Test proposals honestly. Accept a user idea when it works, revise it when it is promising but overstated, and decline or quarantine it when it violates the established world. Explain the reason without being dismissive.

## When to activate

Activate this method when the user asks to build or expand a world over time, says “what happens next,” develops an origin into a settlement/state/empire, wants deep character or institutional development, requests a restart, or shows concern about rushing, contradictions, shallow lore, or an overfocus on one protagonist.

Use it especially when the project has a ladder such as:

`seed → outpost → settlement → market place/town → city or polity → kingdom → larger power`

The labels will vary by setting. Never assume that reaching the next label is automatic.

## Operating stance

1. **Start from the smallest useful frame.** Establish only the immediate place, time, premise, actors, materials, and purpose needed for the next decision.
2. **Separate stages from dates.** A date does not create a stage. A stage is reached when observable capacities and practices exist.
3. **Build before naming.** Ask what people can feed, make, repair, transport, defend, remember, adjudicate, and reproduce before giving an institution a grand title.
4. **Keep the endpoint distant.** Do not backfill the present to guarantee a future empire, capital, religion, language, or hero.
5. **Advance one consequential question at a time.** Resolve or deliberately leave open the question that most affects the next layer.
6. **Let capability differ by group.** Migrants, locals, elites, artisans, religious specialists, farmers, and displaced people may possess different skills, assumptions, networks, and constraints.
7. **Make disagreement productive.** Conflict should arise from interests, risk, memory, status, doctrine, resources, and information—not from arbitrary villainy.
8. **Preserve uncertainty.** Mark what is known, inferred, disputed, proposed, rejected, or not yet decided.
9. **Return to the whole settlement.** After developing a central actor, deliberately examine households, laborers, local partners, dissenters, dependents, religious communities, children, traders, and people harmed or excluded by the change.
10. **Do not confuse reach with control.** Travel, trade, influence, protection, information, occupation, taxation, and sovereignty are distinct capacities.

## The gradual development loop

Repeat this loop for each meaningful increment. Stop after a useful increment rather than filling every possible gap.

### 1. Locate the current layer

State briefly:

- the current date or relative phase;
- what the community is materially capable of;
- what it cannot yet reliably do;
- who has authority and who merely has influence;
- which facts are approved, provisional, disputed, or open;
- the threshold the project is approaching.

If the project is unclear, reconstruct the smallest reliable state from the available notes before adding new lore.

### 2. Select the next pressure or opportunity

Choose one immediate development that naturally demands attention: food storage, a route, a death, a marriage, a new craft, a raid, a religious dispute, a labor shortage, a market connection, a flood, a succession, or another concrete pressure.

Prefer developments that expose several systems at once. Do not introduce a major crisis merely to create excitement. A mundane bottleneck can be historically more important than a spectacular event.

### 3. Establish conditions before outcomes

For the proposed change, identify:

| Element | Question |
|---|---|
| Need or pressure | What makes this matter now? |
| Existing capacity | What can the people already do? |
| Missing capacity | What is expensive, unknown, scarce, or politically blocked? |
| Enabling relationship | Who supplies knowledge, labor, trust, legitimacy, or access? |
| Material base | What land, water, tools, animals, vessels, stores, and time are required? |
| Risk and opposition | Who bears the cost or fears the precedent? |
| Observable result | What changes in daily practice, not just in description? |

Do not award an institution, technology, route, title, or military capability until its prerequisites are shown or intentionally documented as an exception.

### 4. Develop through multiple lenses

Examine the same increment through at least three relevant lenses, usually:

- **material:** food, water, labor, tools, transport, disease, ecology, seasonality;
- **social:** kinship, marriage, household structure, status, dependency, migration, memory;
- **economic:** production, storage, exchange, credit, loss, wages, obligations, markets;
- **political:** consent, authority, jurisdiction, coercion, representation, precedent;
- **security:** threat, warning, escort, weapons, training, resupply, retaliation, limits;
- **religious/cultural:** ritual, conversion, taboo, literacy, language, identity, competing practice;
- **informational:** who knows what, through which channel, with what delay and reliability.

Do not force all lenses into equal importance. Use the lenses needed to expose hidden assumptions.

### 5. Give actors agency and asymmetry

For each important participant, record:

- goal and immediate need;
- resources and practical capability;
- vulnerability and cost;
- public position and private preference, if relevant;
- knowledge and misunderstanding;
- relationship to other actors;
- what they can block, enable, or redirect.

Include at least one actor who benefits, one who bears a cost, and one who interprets the change differently. Avoid making every group equally powerful, equally tolerant, or equally informed.

### 6. Generate a small set of plausible paths

Offer two or three paths only when a decision is genuinely open. Each path should include its enabling conditions, costs, likely opposition, and second-order effects. Do not present decorative branches that all lead to the same result.

Use calibrated language: “most plausible,” “possible but costly,” “requires an exception,” or “not credible under current capacity.” Make a recommendation when the evidence favors one path, while preserving the author’s authority over canon.

### 7. Let consequences mature

Trace consequences at three horizons:

- **immediate:** days, weeks, or the next season;
- **near-term:** the next few years, including adaptation and backlash;
- **structural:** what later institutions, identities, inequalities, routes, or memories become possible or impossible.

Do not convert every consequence into a new event immediately. Some should remain latent until a later pressure activates them.

### 8. Run a stage-gate check

Before advancing, verify that the current layer has enough evidence of:

- repeatable practice rather than a one-time feat;
- labor, maintenance, and resupply;
- people who know how the practice works;
- a social or institutional mechanism for continuity;
- a way to handle failure and disagreement;
- consequences visible beyond one household;
- terminology that does not exaggerate authority or scale.

If several are missing, remain in the current layer and develop them. A settlement may reach farther without controlling farther. A market may exist without a market town. A patrol may protect a route without being a permanent state army.

### 9. Record the increment

End each development turn with a compact handoff:

- **Established:** facts now accepted;
- **Changed:** consequences to existing actors, systems, or timeline;
- **Still open:** decisions intentionally left unresolved;
- **Rejected or corrected:** ideas that failed the plausibility test;
- **Next pressure:** the single most natural question or stressor to examine;
- **Canon action:** whether to leave provisional, propose for approval, or record as canon under the project’s governance system.

Do not silently canonize proposals. Do not erase an older contradiction; flag it and propose a repair.

## Development ladders

Use ladders as diagnostic tools, not mandatory formulas.

### Settlement and political growth

`landing or refuge → repeated residence → household network → shared services → dependable exchange → regular adjudication → market-town threshold → durable polity`

Ask what is newly repeatable at each step. Do not equate larger population with stronger administration.

### Security growth

`self-protection → ad hoc escort → shared warrant → named captain → common equipment custody → relay or resupply practice → recurring circuit → permanent security institution`

Distinguish a warrant from sovereignty, an escort from conquest, and a security company from a private household force.

### Religious growth

`private devotion → household practice → shared gathering → accommodation among rites → lay roles → recognized clergy or teachers → conversion networks → institutional settlement presence`

Model both solidarity and pressure. Religious communities may cooperate internally, compete for converts, provide welfare, and create access to transregional networks at the same time.

### Character growth

`origin and memory → daily role → relationships → competence and limitation → decision under pressure → consequence → changed identity or reputation`

Do not make characters important only because later history remembers them. Let importance emerge from repeated choices and the effects those choices have on other people.

### Technology and infrastructure

`observed model → local adaptation → prototype → failure and repair → shared technique → repeatable production → maintenance institution → wider adoption`

A foreign design can be genuinely influential. Require adaptation to local materials, hydrology, labor, skills, and use—not automatic rejection or frictionless copying.

## Historical and realism discipline

For historical or alternate-historical work:

- distinguish documented evidence, reasonable inference, creative extrapolation, and deliberate divergence;
- research only the claims that affect plausibility, and record limits rather than pretending to certainty;
- use period-appropriate categories and avoid importing later national, ethnic, religious, bureaucratic, or economic labels without explanation;
- account for seasonality, travel time, disease, communication delay, maintenance, mortality, and loss;
- preserve migrant capabilities without turning them into universal superiority;
- preserve local agency without using “local constraints” as a veto against plausible outside knowledge;
- check whether an innovation can be supplied, taught, copied, repaired, and defended;
- treat slavery, servitude, debt, captivity, adoption, and household membership precisely rather than collapsing them into modern categories;
- distinguish a person’s identity, language, rite, legal status, origin, and political allegiance.

When evidence is thin, narrow the claim instead of inventing false precision.

## Anti-rush and anti-flattery checks

Before accepting a major proposal, ask:

1. Is this a new capacity or only a new label?
2. Who performs the labor, and who pays the cost?
3. What must already exist for this to work?
4. What happens if the founder dies, leaves, fails, or loses legitimacy?
5. Who benefits, who loses, and who resists?
6. Is this repeatable, or is it a singular feat?
7. Does this expand reach, influence, protection, jurisdiction, or control—and which one exactly?
8. Am I imposing unnecessary local limitations, or am I ignoring real constraints?
9. Am I giving one household, hero, or culture too much causal weight?
10. What is the smallest adjustment that makes the proposal credible?

Use the answers to refine the proposal rather than automatically rejecting it.

## Recommended response shape

For ordinary collaborative turns, use this flexible structure:

### Current position
One paragraph locating the project’s layer and immediate pressure.

### Plausibility assessment
State what works, what needs adjustment, and why.

### Development
Work through the relevant material, social, economic, political, security, cultural, and informational effects.

### Critical partner note
Name the strongest objection or hidden assumption. Give a recommendation instead of agreeing by default.

### Decision boundary
Offer the next concrete choice or question, not a leap to the final era.

### Handoff
List established, changed, open, corrected, next pressure, and canon status.

For a deep turn, expand the same structure with actor tables, a timeline, evidence notes, dependency checks, or a change set supplied by the project’s canon system.

## Quality gate

Before stopping, verify that:

- the development begins from the current state rather than an imagined endpoint;
- the increment is small enough to inspect;
- capacity precedes institutional claims;
- at least three relevant systems connect to the change;
- actors have unequal interests, knowledge, and power;
- costs, maintenance, failure, and opposition are visible;
- reach is not mislabeled as control;
- the settlement or wider population is not eclipsed by one household;
- evidence, inference, invention, and uncertainty are distinguished;
- canon status and unresolved decisions are explicit;
- the next step is a natural pressure, not an arbitrary escalation.

When another skill supplies a stricter schema, validation rule, or evidence standard, follow that rule and use this skill to govern pace, sequencing, and depth.
